Group members:
	William McLaughlin
	Evan LeValley

Our code expects files will be in a subfolder called 'knapsack'

e.g. /Project4/
     ----knapsack.py
     ----xyz.py
     ----/knapsack/
	 ----p00_c.txt
	 ----xyz.txt

When you run it, it will ask for the three files as input, then run all four tests.

Lastly, it will prompt the user to run all input (0-8) as input and graph the results.
